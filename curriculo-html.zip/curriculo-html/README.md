# Currículo em HTML

Este projeto é um currículo pessoal desenvolvido com HTML puro, sem uso de CSS ou JavaScript.

## 📄 Visualizar Online

Você poderá visualizar este currículo como site ao ativar o GitHub Pages:

👉 https://seunomeusuario.github.io/curriculo-html

## 📁 Estrutura do Projeto

- `index.html`: arquivo principal do currículo.
- `README.md`: este arquivo explicativo.

## 🔧 Tecnologias

- HTML5
